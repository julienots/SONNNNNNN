package com.francois.dualsound

import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * Déclenché quand un appareil Bluetooth audio (casque/écouteurs) se connecte.
 * Si l'automatisation est activée dans les préférences, on applique le
 * préréglage choisi et on tente d'activer l'égaliseur système.
 *
 * Rappel important : ceci ajuste les effets internes de DualSound et tente
 * l'astuce "session globale". Ça n'a AUCUN effet garanti sur YouTube Music
 * ou une autre appli tierce dès que le son passe en Bluetooth — c'est une
 * limite d'Android, pas de cette appli.
 */
class HeadsetAutomationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED) return

        val state = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)
        if (state != BluetoothProfile.STATE_CONNECTED) return

        val store = PresetStore(context.applicationContext)
        if (!store.isAutoOnHeadsetConnectEnabled()) return

        val serviceIntent = Intent(context, PlayerService::class.java).apply {
            action = PlayerService.ACTION_APPLY_AUTOMATION
            putExtra(PlayerService.EXTRA_PRESET_NAME, store.autoHeadsetPresetName())
        }
        runCatching { ContextCompat.startForegroundService(context, serviceIntent) }
    }
}
