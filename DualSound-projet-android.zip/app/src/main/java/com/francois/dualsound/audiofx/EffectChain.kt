package com.francois.dualsound.audiofx

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer

/**
 * Regroupe tous les effets audio (égaliseur 5 bandes, basses, spatialisation
 * "8D"/stéréo large, réverbération) appliqués à UNE session audio donnée
 * (un MediaPlayer précis, ou la session globale 0 pour le mode "système").
 *
 * Chaque effet est créé en best-effort : sur certains appareils / certaines
 * puces audio, un effet donné peut ne pas être disponible (renvoie null) ou
 * refuser certaines valeurs (setStrength non supporté, etc). On avale ces
 * erreurs avec runCatching plutôt que de faire planter la lecture.
 */
class EffectChain(sessionId: Int) {

    val equalizer: Equalizer? = runCatching {
        Equalizer(0, sessionId).apply { enabled = true }
    }.getOrNull()

    val bassBoost: BassBoost? = runCatching {
        BassBoost(0, sessionId).apply { enabled = true }
    }.getOrNull()

    val virtualizer: Virtualizer? = runCatching {
        Virtualizer(0, sessionId).apply { enabled = true }
    }.getOrNull()

    val presetReverb: PresetReverb? = runCatching {
        PresetReverb(0, sessionId).apply { enabled = true }
    }.getOrNull()

    /** true si au moins un effet a pu être créé sur cette session */
    fun isUsable(): Boolean =
        equalizer != null || bassBoost != null || virtualizer != null || presetReverb != null

    fun applyEqLevels(levels: ShortArray) {
        val eq = equalizer ?: return
        runCatching {
            val range = eq.bandLevelRange
            val n = minOf(levels.size, eq.numberOfBands.toInt())
            for (i in 0 until n) {
                val level = levels[i].coerceIn(range[0], range[1])
                eq.setBandLevel(i.toShort(), level)
            }
        }
    }

    /** strength : 0..1000 */
    fun applyBass(strength: Short) {
        val bb = bassBoost ?: return
        val clamped = strength.coerceIn(0.toShort(), 1000.toShort())
        runCatching { bb.setStrength(clamped) }
    }

    /** strength : 0..1000 (0 = pas de spatialisation, 1000 = maximum) */
    fun applyVirtualizer(strength: Short) {
        val v = virtualizer ?: return
        val clamped = strength.coerceIn(0.toShort(), 1000.toShort())
        runCatching { v.setStrength(clamped) }
    }

    /** preset : une des constantes PresetReverb.PRESET_* */
    fun applyReverb(preset: Short) {
        val pr = presetReverb ?: return
        runCatching { pr.preset = preset }
    }

    fun release() {
        runCatching { equalizer?.release() }
        runCatching { bassBoost?.release() }
        runCatching { virtualizer?.release() }
        runCatching { presetReverb?.release() }
    }
}
