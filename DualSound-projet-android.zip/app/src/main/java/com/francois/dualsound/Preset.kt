package com.francois.dualsound

import android.content.Context
import android.media.audiofx.PresetReverb
import org.json.JSONArray
import org.json.JSONObject

/** Les différents "styles" de rotation 8D disponibles. */
enum class EightDMode {
    CIRCULAIRE,        // rotation continue gauche <-> droite (classique)
    FIGURE8,           // motif en huit, avec un léger creux de volume au centre
    DERIVE_ALEATOIRE,  // dérive lente et aléatoire, effet plus organique / apaisant
    LARGE_STATIQUE     // pas de rotation, juste une spatialisation large et stable
}

/**
 * Un préréglage complet : égaliseur + basses + spatialisation + réverbération
 * + réglages de l'effet 8D. Utilisé aussi bien pour les préréglages fournis
 * que pour ceux enregistrés par l'utilisateur.
 */
class SoundPreset(
    val name: String,
    val eqLevels: ShortArray,
    val bassStrength: Short,
    val virtualizerStrength: Short,
    val reverbPreset: Short,
    val eightDMode: EightDMode,
    val eightDSpeedPercent: Int,
    val eightDIntensityPercent: Int
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name)
        put("eq", JSONArray(eqLevels.map { it.toInt() }))
        put("bass", bassStrength.toInt())
        put("virt", virtualizerStrength.toInt())
        put("reverb", reverbPreset.toInt())
        put("mode", eightDMode.name)
        put("speed", eightDSpeedPercent)
        put("intensity", eightDIntensityPercent)
    }

    companion object {
        fun fromJson(o: JSONObject): SoundPreset {
            val eqArr = o.getJSONArray("eq")
            val levels = ShortArray(eqArr.length()) { i -> eqArr.getInt(i).toShort() }
            return SoundPreset(
                name = o.getString("name"),
                eqLevels = levels,
                bassStrength = o.getInt("bass").toShort(),
                virtualizerStrength = o.getInt("virt").toShort(),
                reverbPreset = o.getInt("reverb").toShort(),
                eightDMode = runCatching { EightDMode.valueOf(o.getString("mode")) }
                    .getOrDefault(EightDMode.CIRCULAIRE),
                eightDSpeedPercent = o.getInt("speed"),
                eightDIntensityPercent = o.getInt("intensity")
            )
        }
    }
}

/** Préréglages fournis avec l'appli, pensés pour des usages concrets. */
object BuiltinPresets {
    val DEFAUT = SoundPreset(
        "Défaut", ShortArray(5), 0, 0, PresetReverb.PRESET_NONE,
        EightDMode.CIRCULAIRE, 50, 60
    )
    val BASSES_PROFONDES = SoundPreset(
        "Basses profondes", shortArrayOf(900, 500, 0, -200, -300), 700, 300,
        PresetReverb.PRESET_NONE, EightDMode.LARGE_STATIQUE, 50, 40
    )
    val VOIX_CLAIRES = SoundPreset(
        "Voix claires", shortArrayOf(-300, 0, 600, 700, 200), 100, 200,
        PresetReverb.PRESET_MEDIUMROOM, EightDMode.LARGE_STATIQUE, 50, 20
    )
    val CINEMA_IMMERSIF = SoundPreset(
        "Cinéma immersif", shortArrayOf(400, 200, -100, 100, 300), 400, 800,
        PresetReverb.PRESET_LARGEHALL, EightDMode.CIRCULAIRE, 35, 90
    )
    val SOMMEIL_DOUX = SoundPreset(
        "Sommeil doux", shortArrayOf(-200, -100, -300, -600, -900), 0, 100,
        PresetReverb.PRESET_LARGEROOM, EightDMode.DERIVE_ALEATOIRE, 15, 30
    )
    val SPORT_ENERGIQUE = SoundPreset(
        "Sport énergique", shortArrayOf(600, 300, 200, 400, 500), 800, 400,
        PresetReverb.PRESET_NONE, EightDMode.CIRCULAIRE, 80, 70
    )

    val all = listOf(DEFAUT, BASSES_PROFONDES, VOIX_CLAIRES, CINEMA_IMMERSIF, SOMMEIL_DOUX, SPORT_ENERGIQUE)
}

/**
 * Stockage local (SharedPreferences + JSON) des préréglages personnalisés
 * et des préférences d'automatisation (branchement casque / horaire programmé).
 */
class PresetStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("dualsound_presets", Context.MODE_PRIVATE)

    fun saveCustom(preset: SoundPreset) {
        val list = loadCustom().filterNot { it.name == preset.name } + preset
        writeCustom(list)
    }

    fun deleteCustom(name: String) {
        writeCustom(loadCustom().filterNot { it.name == name })
    }

    private fun writeCustom(list: List<SoundPreset>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_CUSTOM, arr.toString()).apply()
    }

    fun loadCustom(): List<SoundPreset> {
        val raw = prefs.getString(KEY_CUSTOM, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { SoundPreset.fromJson(arr.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    /** Tous les préréglages disponibles : fournis + personnalisés. */
    fun all(): List<SoundPreset> = BuiltinPresets.all + loadCustom()

    fun findByName(name: String?): SoundPreset =
        all().firstOrNull { it.name == name } ?: BuiltinPresets.DEFAUT

    // ---- Automatisation : branchement casque Bluetooth ----
    fun setAutoOnHeadsetConnect(enabled: Boolean, presetName: String) {
        prefs.edit()
            .putBoolean(KEY_AUTO_HEADSET_ENABLED, enabled)
            .putString(KEY_AUTO_HEADSET_PRESET, presetName)
            .apply()
    }
    fun isAutoOnHeadsetConnectEnabled(): Boolean = prefs.getBoolean(KEY_AUTO_HEADSET_ENABLED, false)
    fun autoHeadsetPresetName(): String =
        prefs.getString(KEY_AUTO_HEADSET_PRESET, BuiltinPresets.DEFAUT.name) ?: BuiltinPresets.DEFAUT.name

    // ---- Automatisation : préréglage programmé à heure fixe ----
    fun setScheduled(enabled: Boolean, hour: Int, minute: Int, presetName: String) {
        prefs.edit()
            .putBoolean(KEY_SCHED_ENABLED, enabled)
            .putInt(KEY_SCHED_HOUR, hour)
            .putInt(KEY_SCHED_MINUTE, minute)
            .putString(KEY_SCHED_PRESET, presetName)
            .apply()
    }
    fun isScheduledEnabled(): Boolean = prefs.getBoolean(KEY_SCHED_ENABLED, false)
    fun scheduledHour(): Int = prefs.getInt(KEY_SCHED_HOUR, 22)
    fun scheduledMinute(): Int = prefs.getInt(KEY_SCHED_MINUTE, 30)
    fun scheduledPresetName(): String =
        prefs.getString(KEY_SCHED_PRESET, BuiltinPresets.SOMMEIL_DOUX.name) ?: BuiltinPresets.SOMMEIL_DOUX.name

    companion object {
        private const val KEY_CUSTOM = "custom_presets"
        private const val KEY_AUTO_HEADSET_ENABLED = "auto_headset_enabled"
        private const val KEY_AUTO_HEADSET_PRESET = "auto_headset_preset"
        private const val KEY_SCHED_ENABLED = "sched_enabled"
        private const val KEY_SCHED_HOUR = "sched_hour"
        private const val KEY_SCHED_MINUTE = "sched_minute"
        private const val KEY_SCHED_PRESET = "sched_preset"
    }
}
