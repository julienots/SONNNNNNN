package com.francois.dualsound

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import java.util.Calendar

/**
 * Planifie un préréglage à une heure fixe chaque jour, via AlarmManager.
 * Utilise setAndAllowWhileIdle (non exact) plutôt qu'une alarme exacte :
 * ça évite d'avoir à demander la permission "alarmes et rappels" spéciale,
 * au prix d'un déclenchement pouvant varier de quelques minutes — largement
 * suffisant pour un préréglage d'ambiance (ex: mode Sommeil le soir).
 */
object AutomationScheduler {
    private const val REQUEST_CODE = 7001

    fun scheduleDaily(context: Context, hour: Int, minute: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pendingIntent(context)
        val triggerAt = nextTrigger(hour, minute)
        runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pending) }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        runCatching { am.cancel(pendingIntent(context)) }
    }

    private fun nextTrigger(hour: Int, minute: Int): Long {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ScheduledPresetReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}

/** Reçu chaque jour à l'heure programmée : applique le préréglage puis se replanifie. */
class ScheduledPresetReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = PresetStore(context.applicationContext)
        if (!store.isScheduledEnabled()) return

        val serviceIntent = Intent(context, PlayerService::class.java).apply {
            action = PlayerService.ACTION_APPLY_AUTOMATION
            putExtra(PlayerService.EXTRA_PRESET_NAME, store.scheduledPresetName())
        }
        runCatching { ContextCompat.startForegroundService(context, serviceIntent) }

        AutomationScheduler.scheduleDaily(context, store.scheduledHour(), store.scheduledMinute())
    }
}

/** Reprogramme l'alarme quotidienne après un redémarrage du téléphone. */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val store = PresetStore(context.applicationContext)
        if (store.isScheduledEnabled()) {
            AutomationScheduler.scheduleDaily(context, store.scheduledHour(), store.scheduledMinute())
        }
    }
}
