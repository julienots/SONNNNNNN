package com.francois.dualsound

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlin.math.PI
import kotlin.math.cos

class PlayerService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): PlayerService = this@PlayerService
    }

    private val binder = LocalBinder()

    // --- Lecteurs ---
    private var playerLeft: MediaPlayer? = null
    private var playerRight: MediaPlayer? = null
    private var playerSingle: MediaPlayer? = null

    // --- Effets ---
    private var eqLeft: Equalizer? = null
    private var eqRight: Equalizer? = null
    private var eqSingle: Equalizer? = null
    private var eqGlobal: Equalizer? = null

    // --- Etat égaliseur (5 bandes, en millibels, -1500..1500) ---
    val bandCount = 5
    var eqLevels = ShortArray(bandCount)

    // --- Etat 8D ---
    private val eightDHandler = Handler(Looper.getMainLooper())
    private var eightDRunnable: Runnable? = null
    var eightDEnabled = false
        private set
    private var eightDPeriodMs = 6000L
    private var eightDStartTime = 0L

    var globalEqEnabled = false
        private set

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        return START_STICKY
    }

    // ================= MODE DUAL =================

    fun playDual(uriLeft: Uri, uriRight: Uri) {
        stopDual()

        playerLeft = MediaPlayer().apply {
            setDataSource(applicationContext, uriLeft)
            isLooping = true
            prepareAsync()
        }
        playerLeft?.setOnPreparedListener {
            it.setVolume(1f, 0f)
            it.start()
            eqLeft = attachEqualizer(it.audioSessionId)
        }

        playerRight = MediaPlayer().apply {
            setDataSource(applicationContext, uriRight)
            isLooping = true
            prepareAsync()
        }
        playerRight?.setOnPreparedListener {
            it.setVolume(0f, 1f) // 100% canal droit uniquement
            it.start()
            eqRight = attachEqualizer(it.audioSessionId)
        }

        updateNotification("Lecture séparée gauche / droite")
    }

    fun stopDual() {
        eqLeft?.release(); eqLeft = null
        eqRight?.release(); eqRight = null
        playerLeft?.runCatching { stop(); release() }; playerLeft = null
        playerRight?.runCatching { stop(); release() }; playerRight = null
        updateNotification("Prêt")
    }

    // ================= MODE NORMAL + 8D =================

    fun playSingle(uri: Uri) {
        stopSingle()
        playerSingle = MediaPlayer().apply {
            setDataSource(applicationContext, uri)
            isLooping = true
            setOnPreparedListener {
                it.start()
                eqSingle = attachEqualizer(it.audioSessionId)
                if (eightDEnabled) startEightD()
            }
            prepareAsync()
        }
        updateNotification("Lecture en cours (8D: ${if (eightDEnabled) "on" else "off"})")
    }

    fun stopSingle() {
        stopEightD()
        eqSingle?.release(); eqSingle = null
        playerSingle?.runCatching { stop(); release() }; playerSingle = null
        updateNotification("Prêt")
    }

    fun set8DEnabled(enabled: Boolean) {
        eightDEnabled = enabled
        if (enabled && playerSingle != null) startEightD() else stopEightD()
    }

    /** speedPercent: 0 (lent) .. 100 (rapide) */
    fun set8DSpeed(speedPercent: Int) {
        val clamped = speedPercent.coerceIn(0, 100)
        eightDPeriodMs = (12000 - clamped * 100).toLong().coerceAtLeast(1500L)
    }

    private fun startEightD() {
        stopEightD()
        eightDStartTime = System.currentTimeMillis()
        eightDRunnable = object : Runnable {
            override fun run() {
                val player = playerSingle
                if (player != null) {
                    val elapsed = System.currentTimeMillis() - eightDStartTime
                    val angle = (elapsed % eightDPeriodMs).toDouble() / eightDPeriodMs * 2 * PI
                    val left = (0.35 + 0.65 * (0.5 + 0.5 * cos(angle))).toFloat()
                    val right = (0.35 + 0.65 * (0.5 + 0.5 * cos(angle + PI))).toFloat()
                    player.runCatching { setVolume(left, right) }
                    eightDHandler.postDelayed(this, 40L)
                }
            }
        }
        eightDHandler.post(eightDRunnable!!)
    }

    private fun stopEightD() {
        eightDRunnable?.let { eightDHandler.removeCallbacks(it) }
        eightDRunnable = null
    }

    // ================= EGALISEUR =================

    private fun attachEqualizer(sessionId: Int): Equalizer? {
        return try {
            val eq = Equalizer(0, sessionId)
            applyEqLevels(eq)
            eq.enabled = true
            eq
        } catch (e: Exception) {
            null
        }
    }

    private fun applyEqLevels(eq: Equalizer) {
        val range = eq.bandLevelRange
        val n = minOf(bandCount, eq.numberOfBands.toInt())
        for (i in 0 until n) {
            val level = eqLevels[i].coerceIn(range[0], range[1])
            eq.runCatching { setBandLevel(i.toShort(), level) }
        }
    }

    fun setEqBand(band: Int, levelMillibel: Short) {
        if (band !in 0 until bandCount) return
        eqLevels[band] = levelMillibel
        listOfNotNull(eqLeft, eqRight, eqSingle, eqGlobal).forEach { applyEqLevels(it) }
    }

    fun resetEq() {
        eqLevels = ShortArray(bandCount)
        listOfNotNull(eqLeft, eqRight, eqSingle, eqGlobal).forEach { applyEqLevels(it) }
    }

    fun getBandFrequencyLabel(band: Int): String {
        val labels = arrayOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
        return labels.getOrElse(band) { "" }
    }

    // ================= EQ GLOBAL EXPERIMENTAL =================

    fun setGlobalEqEnabled(enabled: Boolean): Boolean {
        globalEqEnabled = enabled
        return if (enabled) {
            eqGlobal = try {
                val eq = Equalizer(0, 0)
                applyEqLevels(eq)
                eq.enabled = true
                eq
            } catch (e: Exception) {
                globalEqEnabled = false
                null
            }
            eqGlobal != null
        } else {
            eqGlobal?.release()
            eqGlobal = null
            true
        }
    }

    // ================= NOTIFICATION =================

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Lecture audio", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String = "Prêt"): Notification {
        val stopIntent = Intent(this, PlayerService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DualSound")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Tout arrêter", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        stopDual()
        stopSingle()
        eqGlobal?.release(); eqGlobal = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "dualsound_playback"
        const val NOTIF_ID = 42
        const val ACTION_STOP = "com.francois.dualsound.STOP"
    }
}
