package com.francois.dualsound

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.francois.dualsound.audiofx.EffectChain
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class PlayerService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): PlayerService = this@PlayerService
    }

    private val binder = LocalBinder()

    // --- Lecteurs ---
    private var playerLeft: MediaPlayer? = null
    private var playerRight: MediaPlayer? = null
    private var playerSingle: MediaPlayer? = null

    // --- Chaînes d'effets (une par session audio) ---
    private var effectsLeft: EffectChain? = null
    private var effectsRight: EffectChain? = null
    private var effectsSingle: EffectChain? = null
    private var effectsGlobal: EffectChain? = null

    // --- Etat égaliseur (5 bandes, en millibels, -1500..1500) ---
    val bandCount = 5
    var eqLevels = ShortArray(bandCount)
        private set

    // --- Etat basses / spatialisation / réverbération (partagé par toutes les sessions) ---
    var bassStrength: Short = 0
        private set
    var virtualizerStrength: Short = 0
        private set
    var reverbPreset: Short = 0
        private set

    // --- Etat 8D ---
    private val fxHandler = Handler(Looper.getMainLooper())
    private var eightDRunnable: Runnable? = null
    var eightDEnabled = false
        private set
    var eightDMode = EightDMode.CIRCULAIRE
        private set
    private var eightDPeriodMs = 6000L
    private var eightDStartTime = 0L
    var eightDIntensityPercent = 60
        private set
    private var driftValue = 0.0

    var globalEqEnabled = false
        private set

    // --- Minuterie de sommeil ---
    private var sleepTimerRunnable: Runnable? = null
    var sleepTimerActive = false
        private set

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        when (intent?.action) {
            ACTION_STOP -> {
                stopDual()
                stopSingle()
            }
            ACTION_APPLY_AUTOMATION -> {
                val presetName = intent.getStringExtra(EXTRA_PRESET_NAME)
                val preset = PresetStore(applicationContext).findByName(presetName)
                applyPreset(preset)
                val ok = setGlobalEqEnabled(true)
                updateNotification(
                    if (ok) "Auto : ${preset.name} (égaliseur système actif)"
                    else "Auto : ${preset.name} (égaliseur système indisponible ici)"
                )
            }
        }
        return START_STICKY
    }

    // ================= MODE DUAL =================

    fun playDual(uriLeft: Uri, uriRight: Uri) {
        stopDual()

        playerLeft = MediaPlayer().apply {
            setDataSource(applicationContext, uriLeft)
            isLooping = true
            prepareAsync()
        }
        playerLeft?.setOnPreparedListener {
            it.setVolume(1f, 0f)
            it.start()
            effectsLeft = attachEffects(it.audioSessionId)
        }

        playerRight = MediaPlayer().apply {
            setDataSource(applicationContext, uriRight)
            isLooping = true
            prepareAsync()
        }
        playerRight?.setOnPreparedListener {
            it.setVolume(0f, 1f) // 100% canal droit uniquement
            it.start()
            effectsRight = attachEffects(it.audioSessionId)
        }

        updateNotification("Lecture séparée gauche / droite")
    }

    fun stopDual() {
        effectsLeft?.release(); effectsLeft = null
        effectsRight?.release(); effectsRight = null
        playerLeft?.runCatching { stop(); release() }; playerLeft = null
        playerRight?.runCatching { stop(); release() }; playerRight = null
        updateNotification("Prêt")
    }

    // ================= MODE NORMAL + 8D =================

    fun playSingle(uri: Uri) {
        stopSingle()
        playerSingle = MediaPlayer().apply {
            setDataSource(applicationContext, uri)
            isLooping = true
            setOnPreparedListener {
                it.start()
                effectsSingle = attachEffects(it.audioSessionId)
                if (eightDEnabled) startEightD()
            }
            prepareAsync()
        }
        updateNotification("Lecture en cours (8D : ${if (eightDEnabled) "on" else "off"})")
    }

    fun stopSingle() {
        stopEightD()
        cancelSleepTimer()
        effectsSingle?.release(); effectsSingle = null
        playerSingle?.runCatching { stop(); release() }; playerSingle = null
        updateNotification("Prêt")
    }

    fun set8DEnabled(enabled: Boolean) {
        eightDEnabled = enabled
        if (enabled && playerSingle != null) startEightD() else stopEightD()
    }

    fun set8DMode(mode: EightDMode) {
        eightDMode = mode
        driftValue = 0.0
    }

    /** speedPercent: 0 (lent) .. 100 (rapide) */
    fun set8DSpeed(speedPercent: Int) {
        val clamped = speedPercent.coerceIn(0, 100)
        eightDPeriodMs = (12000 - clamped * 100).toLong().coerceAtLeast(1500L)
    }

    /** intensityPercent: 0 (pas de rotation perceptible) .. 100 (maximum) */
    fun set8DIntensity(intensityPercent: Int) {
        eightDIntensityPercent = intensityPercent.coerceIn(0, 100)
    }

    private fun startEightD() {
        stopEightD()
        eightDStartTime = System.currentTimeMillis()
        eightDRunnable = object : Runnable {
            override fun run() {
                val player = playerSingle
                if (player != null) {
                    val elapsed = System.currentTimeMillis() - eightDStartTime
                    val (left, right) = computePan(elapsed)
                    player.runCatching { setVolume(left, right) }
                    fxHandler.postDelayed(this, 40L)
                }
            }
        }
        fxHandler.post(eightDRunnable!!)
    }

    private fun stopEightD() {
        eightDRunnable?.let { fxHandler.removeCallbacks(it) }
        eightDRunnable = null
    }

    /** Calcule le panoramique gauche/droite selon le mode 8D choisi. */
    private fun computePan(elapsedMs: Long): Pair<Float, Float> {
        val amp = eightDIntensityPercent.coerceIn(0, 100) / 100.0
        return when (eightDMode) {
            EightDMode.CIRCULAIRE -> {
                val angle = (elapsedMs % eightDPeriodMs).toDouble() / eightDPeriodMs * 2 * PI
                val left = 1.0 - amp / 2 + amp / 2 * cos(angle)
                val right = 1.0 - amp / 2 + amp / 2 * cos(angle + PI)
                left.toFloat().coerceIn(0f, 1f) to right.toFloat().coerceIn(0f, 1f)
            }
            EightDMode.FIGURE8 -> {
                val angle = (elapsedMs % eightDPeriodMs).toDouble() / eightDPeriodMs * 2 * PI
                val pan = sin(angle)
                val pulse = 0.85 + 0.15 * cos(2 * angle)
                val left = (1.0 - amp / 2 - amp / 2 * pan) * pulse
                val right = (1.0 - amp / 2 + amp / 2 * pan) * pulse
                left.toFloat().coerceIn(0f, 1f) to right.toFloat().coerceIn(0f, 1f)
            }
            EightDMode.DERIVE_ALEATOIRE -> {
                driftValue = (driftValue + Random.nextDouble(-1.0, 1.0) * 0.03).coerceIn(-1.0, 1.0)
                val left = 1.0 - amp / 2 - amp / 2 * driftValue
                val right = 1.0 - amp / 2 + amp / 2 * driftValue
                left.toFloat().coerceIn(0f, 1f) to right.toFloat().coerceIn(0f, 1f)
            }
            EightDMode.LARGE_STATIQUE -> 1f to 1f
        }
    }

    // ================= EFFETS (EQ / basses / spatialisation / réverb) =================

    private fun attachEffects(sessionId: Int): EffectChain {
        val chain = EffectChain(sessionId)
        chain.applyEqLevels(eqLevels)
        chain.applyBass(bassStrength)
        chain.applyVirtualizer(virtualizerStrength)
        chain.applyReverb(reverbPreset)
        return chain
    }

    private fun allChains(): List<EffectChain> =
        listOfNotNull(effectsLeft, effectsRight, effectsSingle, effectsGlobal)

    fun setEqBand(band: Int, levelMillibel: Short) {
        if (band !in 0 until bandCount) return
        eqLevels[band] = levelMillibel
        allChains().forEach { it.applyEqLevels(eqLevels) }
    }

    fun resetEq() {
        eqLevels = ShortArray(bandCount)
        allChains().forEach { it.applyEqLevels(eqLevels) }
    }

    fun setBass(strength: Short) {
        bassStrength = strength.coerceIn(0.toShort(), 1000.toShort())
        allChains().forEach { it.applyBass(bassStrength) }
    }

    fun setVirtualizer(strength: Short) {
        virtualizerStrength = strength.coerceIn(0.toShort(), 1000.toShort())
        allChains().forEach { it.applyVirtualizer(virtualizerStrength) }
    }

    fun setReverb(preset: Short) {
        reverbPreset = preset
        allChains().forEach { it.applyReverb(reverbPreset) }
    }

    fun getBandFrequencyLabel(band: Int): String {
        val labels = arrayOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
        return labels.getOrElse(band) { "" }
    }

    /** Applique un préréglage complet (EQ + basses + spatialisation + réverb + 8D). */
    fun applyPreset(preset: SoundPreset) {
        eqLevels = preset.eqLevels.copyOf()
        bassStrength = preset.bassStrength
        virtualizerStrength = preset.virtualizerStrength
        reverbPreset = preset.reverbPreset
        eightDMode = preset.eightDMode
        set8DSpeed(preset.eightDSpeedPercent)
        eightDIntensityPercent = preset.eightDIntensityPercent
        allChains().forEach { chain ->
            chain.applyEqLevels(eqLevels)
            chain.applyBass(bassStrength)
            chain.applyVirtualizer(virtualizerStrength)
            chain.applyReverb(reverbPreset)
        }
        updateNotification("Préréglage : ${preset.name}")
    }

    fun currentAsPreset(name: String): SoundPreset = SoundPreset(
        name, eqLevels.copyOf(), bassStrength, virtualizerStrength, reverbPreset,
        eightDMode, percentFromPeriod(), eightDIntensityPercent
    )

    private fun percentFromPeriod(): Int {
        // inverse de set8DSpeed
        val clamped = (12000L - eightDPeriodMs).coerceAtLeast(0L)
        return (clamped / 100).toInt().coerceIn(0, 100)
    }

    // ================= EQ GLOBAL EXPERIMENTAL (tentative "tout le téléphone") =================

    /**
     * Tente d'attacher les effets à la session audio globale (0). C'est une astuce
     * non officielle : Android ne garantit aucune API publique pour modifier le son
     * d'autres applis. Sur beaucoup d'appareils ça ne touche que la sortie haut-parleur
     * / filaire, et RIEN en Bluetooth (YouTube Music via écouteurs sans fil inclus).
     */
    fun setGlobalEqEnabled(enabled: Boolean): Boolean {
        return if (enabled) {
            val chain = EffectChain(0)
            val usable = chain.isUsable()
            if (usable) {
                chain.applyEqLevels(eqLevels)
                chain.applyBass(bassStrength)
                chain.applyVirtualizer(virtualizerStrength)
                chain.applyReverb(reverbPreset)
                effectsGlobal = chain
                globalEqEnabled = true
            } else {
                chain.release()
                globalEqEnabled = false
            }
            globalEqEnabled
        } else {
            effectsGlobal?.release()
            effectsGlobal = null
            globalEqEnabled = false
            true
        }
    }

    // ================= MINUTERIE DE SOMMEIL =================

    /** Programme un arrêt en fondu après [minutes] minutes de lecture interne. */
    fun setSleepTimer(minutes: Int) {
        cancelSleepTimer()
        if (minutes <= 0) return
        sleepTimerActive = true
        val fadeStartDelay = (minutes * 60_000L - FADE_DURATION_MS).coerceAtLeast(0L)
        sleepTimerRunnable = Runnable { fadeOutAndStopAll() }
        fxHandler.postDelayed(sleepTimerRunnable!!, fadeStartDelay)
        updateNotification("Minuterie de sommeil : $minutes min")
    }

    fun cancelSleepTimer() {
        sleepTimerRunnable?.let { fxHandler.removeCallbacks(it) }
        sleepTimerRunnable = null
        sleepTimerActive = false
    }

    private fun fadeOutAndStopAll() {
        val steps = 25
        val stepDelay = FADE_DURATION_MS / steps
        var step = 0
        val fadeRunnable = object : Runnable {
            override fun run() {
                step++
                val vol = (1f - step.toFloat() / steps).coerceIn(0f, 1f)
                playerSingle?.runCatching { setVolume(vol, vol) }
                playerLeft?.runCatching { setVolume(vol, 0f) }
                playerRight?.runCatching { setVolume(0f, vol) }
                if (step < steps) {
                    fxHandler.postDelayed(this, stepDelay)
                } else {
                    stopSingle()
                    stopDual()
                }
            }
        }
        fxHandler.post(fadeRunnable)
    }

    // ================= NOTIFICATION =================

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Lecture audio", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String = "Prêt"): Notification {
        val stopIntent = Intent(this, PlayerService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("DualSound")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Tout arrêter", stopPending)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        stopDual()
        stopSingle()
        effectsGlobal?.release(); effectsGlobal = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "dualsound_playback"
        const val NOTIF_ID = 42
        const val ACTION_STOP = "com.francois.dualsound.STOP"
        const val ACTION_APPLY_AUTOMATION = "com.francois.dualsound.APPLY_AUTOMATION"
        const val EXTRA_PRESET_NAME = "preset_name"
        private const val FADE_DURATION_MS = 15_000L
    }
}
