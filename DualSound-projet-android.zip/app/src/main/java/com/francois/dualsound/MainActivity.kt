package com.francois.dualsound

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.francois.dualsound.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var service: PlayerService? = null
    private var bound = false

    private var leftUri: Uri? = null
    private var rightUri: Uri? = null
    private var singleUri: Uri? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, ibinder: IBinder?) {
            val localBinder = ibinder as PlayerService.LocalBinder
            service = localBinder.getService()
            bound = true
            binding.txtStatus.text = "Service connecté"
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
        }
    }

    private val pickLeftLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistPermission(it)
            leftUri = it
            binding.txtLeftFile.text = fileNameOf(it)
        }
    }

    private val pickRightLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistPermission(it)
            rightUri = it
            binding.txtRightFile.text = fileNameOf(it)
        }
    }

    private val pickSingleLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistPermission(it)
            singleUri = it
            binding.txtSingleFile.text = fileNameOf(it)
        }
    }

    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        askNotificationPermissionIfNeeded()
        buildEqSliders()
        startAndBindService()

        binding.btnPickLeft.setOnClickListener { pickLeftLauncher.launch(arrayOf("audio/*")) }
        binding.btnPickRight.setOnClickListener { pickRightLauncher.launch(arrayOf("audio/*")) }
        binding.btnPickSingle.setOnClickListener { pickSingleLauncher.launch(arrayOf("audio/*")) }

        binding.btnPlayDual.setOnClickListener {
            val l = leftUri; val r = rightUri
            if (l == null || r == null) {
                toast("Choisis un fichier pour chaque oreille")
            } else {
                service?.playDual(l, r)
                binding.txtStatus.text = "Lecture séparée en cours"
            }
        }
        binding.btnStopDual.setOnClickListener {
            service?.stopDual()
            binding.txtStatus.text = "Arrêté"
        }

        binding.btnPlaySingle.setOnClickListener {
            val u = singleUri
            if (u == null) {
                toast("Choisis un fichier audio")
            } else {
                service?.playSingle(u)
                binding.txtStatus.text = "Lecture en cours"
            }
        }
        binding.btnStopSingle.setOnClickListener {
            service?.stopSingle()
            binding.txtStatus.text = "Arrêté"
        }

        binding.switch8D.setOnCheckedChangeListener { _, checked ->
            service?.set8DEnabled(checked)
        }

        binding.seek8DSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                service?.set8DSpeed(progress)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        binding.btnResetEq.setOnClickListener {
            service?.resetEq()
            resetEqSliders()
        }

        binding.switchGlobalEq.setOnCheckedChangeListener { _, checked ->
            val success = service?.setGlobalEqEnabled(checked) ?: false
            if (checked && !success) {
                toast("Non supporté sur cet appareil")
                binding.switchGlobalEq.isChecked = false
            }
        }
    }

    private fun buildEqSliders() {
        binding.eqContainer.removeAllViews()
        for (i in 0 until 5) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val seek = SeekBar(this).apply {
                max = 100
                progress = 50
                rotation = 270f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 160
                ).apply { setMargins(0, 40, 0, 40) }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            val level = ((progress - 50) * 30).toShort() // -1500..1500 mB
                            service?.setEqBand(i, level)
                        }
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            val label = TextView(this).apply {
                text = service?.getBandFrequencyLabel(i) ?: ""
                textSize = 10f
                setTextColor(getColor(R.color.text_secondary))
                gravity = android.view.Gravity.CENTER
            }
            col.addView(seek)
            col.addView(label)
            binding.eqContainer.addView(col)
        }
    }

    private fun resetEqSliders() {
        for (i in 0 until binding.eqContainer.childCount) {
            val col = binding.eqContainer.getChildAt(i) as LinearLayout
            (col.getChildAt(0) as SeekBar).progress = 50
        }
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun startAndBindService() {
        val intent = Intent(this, PlayerService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun persistPermission(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun fileNameOf(uri: Uri): String {
        var name = uri.lastPathSegment ?: "fichier sélectionné"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        if (bound) {
            unbindService(connection)
            bound = false
        }
        super.onDestroy()
    }
}
