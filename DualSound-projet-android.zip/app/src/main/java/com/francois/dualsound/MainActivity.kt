package com.francois.dualsound

import android.Manifest
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.media.audiofx.PresetReverb
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.francois.dualsound.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var service: PlayerService? = null
    private var bound = false

    private lateinit var presetStore: PresetStore

    private var leftUri: Uri? = null
    private var rightUri: Uri? = null
    private var singleUri: Uri? = null

    private val reverbLabels = listOf(
        "Aucune", "Petite pièce", "Pièce moyenne", "Grande pièce",
        "Salle moyenne", "Grande salle", "Plaque"
    )
    private val reverbValues = shortArrayOf(
        PresetReverb.PRESET_NONE, PresetReverb.PRESET_SMALLROOM, PresetReverb.PRESET_MEDIUMROOM,
        PresetReverb.PRESET_LARGEROOM, PresetReverb.PRESET_MEDIUMHALL, PresetReverb.PRESET_LARGEHALL,
        PresetReverb.PRESET_PLATE
    )

    private var scheduledHour = 22
    private var scheduledMinute = 30

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, ibinder: IBinder?) {
            val localBinder = ibinder as PlayerService.LocalBinder
            service = localBinder.getService()
            bound = true
            binding.txtStatus.text = "Service connecté"
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
        }
    }

    private val pickLeftLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistPermission(it)
            leftUri = it
            binding.txtLeftFile.text = fileNameOf(it)
        }
    }

    private val pickRightLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistPermission(it)
            rightUri = it
            binding.txtRightFile.text = fileNameOf(it)
        }
    }

    private val pickSingleLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            persistPermission(it)
            singleUri = it
            binding.txtSingleFile.text = fileNameOf(it)
        }
    }

    private val notifPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val bluetoothPermLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) {
            binding.switchAutoHeadset.isChecked = false
            toast("Permission Bluetooth refusée : l'automatisation ne peut pas détecter le branchement")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        presetStore = PresetStore(this)

        askNotificationPermissionIfNeeded()
        buildEqSliders()
        setupReverbSpinner()
        setupPresetSpinners()
        loadAutomationPrefs()
        startAndBindService()

        binding.btnPickLeft.setOnClickListener { pickLeftLauncher.launch(arrayOf("audio/*")) }
        binding.btnPickRight.setOnClickListener { pickRightLauncher.launch(arrayOf("audio/*")) }
        binding.btnPickSingle.setOnClickListener { pickSingleLauncher.launch(arrayOf("audio/*")) }

        binding.btnPlayDual.setOnClickListener {
            val l = leftUri; val r = rightUri
            if (l == null || r == null) {
                toast("Choisis un fichier pour chaque oreille")
            } else {
                service?.playDual(l, r)
                binding.txtStatus.text = "Lecture séparée en cours"
            }
        }
        binding.btnStopDual.setOnClickListener {
            service?.stopDual()
            binding.txtStatus.text = "Arrêté"
        }

        binding.btnPlaySingle.setOnClickListener {
            val u = singleUri
            if (u == null) {
                toast("Choisis un fichier audio")
            } else {
                service?.playSingle(u)
                binding.txtStatus.text = "Lecture en cours"
            }
        }
        binding.btnStopSingle.setOnClickListener {
            service?.stopSingle()
            binding.txtStatus.text = "Arrêté"
        }

        binding.switch8D.setOnCheckedChangeListener { _, checked ->
            service?.set8DEnabled(checked)
        }

        binding.radioGroup8DMode.setOnCheckedChangeListener { _, checkedId ->
            val mode = when (checkedId) {
                R.id.radio8dFigure8 -> EightDMode.FIGURE8
                R.id.radio8dDerive -> EightDMode.DERIVE_ALEATOIRE
                R.id.radio8dLarge -> EightDMode.LARGE_STATIQUE
                else -> EightDMode.CIRCULAIRE
            }
            service?.set8DMode(mode)
        }

        binding.seek8DSpeed.setOnSeekBarChangeListener(simpleSeekListener { progress ->
            service?.set8DSpeed(progress)
        })

        binding.seek8DIntensity.setOnSeekBarChangeListener(simpleSeekListener { progress ->
            service?.set8DIntensity(progress)
        })

        binding.btnResetEq.setOnClickListener {
            service?.resetEq()
            resetEqSliders()
        }

        binding.seekBass.setOnSeekBarChangeListener(simpleSeekListener { progress ->
            service?.setBass(progress.toShort())
        })

        binding.seekVirtualizer.setOnSeekBarChangeListener(simpleSeekListener { progress ->
            service?.setVirtualizer(progress.toShort())
        })

        binding.spinnerReverb.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                service?.setReverb(reverbValues[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnApplyPreset.setOnClickListener {
            val name = binding.spinnerPresets.selectedItem as? String ?: return@setOnClickListener
            val preset = presetStore.findByName(name)
            service?.applyPreset(preset)
            refreshUiFromService()
            toast("Préréglage « ${preset.name} » appliqué")
        }

        binding.btnSavePreset.setOnClickListener { showSavePresetDialog() }

        binding.switchGlobalEq.setOnCheckedChangeListener { _, checked ->
            val success = service?.setGlobalEqEnabled(checked) ?: false
            if (checked && !success) {
                toast("Non pris en charge sur cet appareil pour cette sortie audio")
                binding.switchGlobalEq.isChecked = false
            }
        }

        binding.switchAutoHeadset.setOnCheckedChangeListener { _, checked ->
            if (checked) askBluetoothPermissionIfNeeded()
            val presetName = binding.spinnerAutoHeadsetPreset.selectedItem as? String ?: BuiltinPresets.DEFAUT.name
            presetStore.setAutoOnHeadsetConnect(checked, presetName)
        }
        binding.spinnerAutoHeadsetPreset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (binding.switchAutoHeadset.isChecked) {
                    val name = binding.spinnerAutoHeadsetPreset.selectedItem as? String ?: return
                    presetStore.setAutoOnHeadsetConnect(true, name)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnPickTime.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                scheduledHour = hour
                scheduledMinute = minute
                binding.btnPickTime.text = "Choisir l'heure : %02d:%02d".format(hour, minute)
                if (binding.switchScheduled.isChecked) applyScheduledPrefsAndReschedule()
            }, scheduledHour, scheduledMinute, true).show()
        }

        binding.switchScheduled.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                applyScheduledPrefsAndReschedule()
            } else {
                presetStore.setScheduled(false, scheduledHour, scheduledMinute, currentScheduledPresetName())
                AutomationScheduler.cancel(this)
            }
        }
        binding.spinnerScheduledPreset.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                if (binding.switchScheduled.isChecked) applyScheduledPrefsAndReschedule()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.btnSleep10.setOnClickListener { setSleepTimer(10) }
        binding.btnSleep20.setOnClickListener { setSleepTimer(20) }
        binding.btnSleep30.setOnClickListener { setSleepTimer(30) }
        binding.btnSleep60.setOnClickListener { setSleepTimer(60) }
        binding.btnSleepCancel.setOnClickListener {
            service?.cancelSleepTimer()
            toast("Minuterie annulée")
        }
    }

    // ================= PRESETS =================

    private fun setupPresetSpinners() {
        refreshPresetAdapters()
    }

    private fun refreshPresetAdapters() {
        val names = presetStore.all().map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        binding.spinnerPresets.adapter = adapter
        binding.spinnerAutoHeadsetPreset.adapter = adapter
        binding.spinnerScheduledPreset.adapter = adapter

        selectSpinnerValue(binding.spinnerAutoHeadsetPreset, presetStore.autoHeadsetPresetName())
        selectSpinnerValue(binding.spinnerScheduledPreset, presetStore.scheduledPresetName())
    }

    private fun selectSpinnerValue(spinner: android.widget.Spinner, value: String) {
        val adapter = spinner.adapter as? ArrayAdapter<String> ?: return
        val index = (0 until adapter.count).firstOrNull { adapter.getItem(it) == value } ?: 0
        spinner.setSelection(index)
    }

    private fun showSavePresetDialog() {
        val input = EditText(this).apply { hint = "Nom du préréglage" }
        AlertDialog.Builder(this)
            .setTitle("Enregistrer les réglages actuels")
            .setView(input)
            .setPositiveButton("Enregistrer") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    toast("Donne un nom à ton préréglage")
                    return@setPositiveButton
                }
                val svc = service ?: return@setPositiveButton
                presetStore.saveCustom(svc.currentAsPreset(name))
                refreshPresetAdapters()
                toast("Préréglage « $name » enregistré")
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun refreshUiFromService() {
        val svc = service ?: return
        for (i in 0 until binding.eqContainer.childCount) {
            val col = binding.eqContainer.getChildAt(i) as LinearLayout
            val seek = col.getChildAt(0) as SeekBar
            seek.progress = (svc.eqLevels[i] / 30) + 50
        }
        binding.seekBass.progress = svc.bassStrength.toInt()
        binding.seekVirtualizer.progress = svc.virtualizerStrength.toInt()
        binding.seek8DIntensity.progress = svc.eightDIntensityPercent
        when (svc.eightDMode) {
            EightDMode.CIRCULAIRE -> binding.radio8dCirculaire.isChecked = true
            EightDMode.FIGURE8 -> binding.radio8dFigure8.isChecked = true
            EightDMode.DERIVE_ALEATOIRE -> binding.radio8dDerive.isChecked = true
            EightDMode.LARGE_STATIQUE -> binding.radio8dLarge.isChecked = true
        }
        val reverbIndex = reverbValues.indexOf(svc.reverbPreset).takeIf { it >= 0 } ?: 0
        binding.spinnerReverb.setSelection(reverbIndex)
    }

    // ================= AUTOMATISATIONS =================

    private fun loadAutomationPrefs() {
        binding.switchAutoHeadset.isChecked = presetStore.isAutoOnHeadsetConnectEnabled()
        binding.switchScheduled.isChecked = presetStore.isScheduledEnabled()
        scheduledHour = presetStore.scheduledHour()
        scheduledMinute = presetStore.scheduledMinute()
        binding.btnPickTime.text = "Choisir l'heure : %02d:%02d".format(scheduledHour, scheduledMinute)
    }

    private fun currentScheduledPresetName(): String =
        binding.spinnerScheduledPreset.selectedItem as? String ?: BuiltinPresets.SOMMEIL_DOUX.name

    private fun applyScheduledPrefsAndReschedule() {
        val name = currentScheduledPresetName()
        presetStore.setScheduled(true, scheduledHour, scheduledMinute, name)
        AutomationScheduler.scheduleDaily(this, scheduledHour, scheduledMinute)
        toast("Préréglage « $name » programmé chaque jour à %02d:%02d".format(scheduledHour, scheduledMinute))
    }

    private fun askBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                bluetoothPermLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
            }
        }
    }

    private fun setSleepTimer(minutes: Int) {
        service?.setSleepTimer(minutes)
        toast("Minuterie réglée sur $minutes min (fondu progressif à la fin)")
    }

    // ================= UI HELPERS =================

    private fun buildEqSliders() {
        binding.eqContainer.removeAllViews()
        for (i in 0 until 5) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            val seek = SeekBar(this).apply {
                max = 100
                progress = 50
                rotation = 270f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 160
                ).apply { setMargins(0, 40, 0, 40) }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) {
                            val level = ((progress - 50) * 30).toShort() // -1500..1500 mB
                            service?.setEqBand(i, level)
                        }
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            val label = TextView(this).apply {
                text = service?.getBandFrequencyLabel(i) ?: ""
                textSize = 10f
                setTextColor(getColor(R.color.text_secondary))
                gravity = android.view.Gravity.CENTER
            }
            col.addView(seek)
            col.addView(label)
            binding.eqContainer.addView(col)
        }
    }

    private fun resetEqSliders() {
        for (i in 0 until binding.eqContainer.childCount) {
            val col = binding.eqContainer.getChildAt(i) as LinearLayout
            (col.getChildAt(0) as SeekBar).progress = 50
        }
    }

    private fun setupReverbSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, reverbLabels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerReverb.adapter = adapter
    }

    /** Petit raccourci pour ne réagir qu'aux changements venant de l'utilisateur. */
    private fun simpleSeekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun startAndBindService() {
        val intent = Intent(this, PlayerService::class.java)
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun persistPermission(uri: Uri) {
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    private fun fileNameOf(uri: Uri): String {
        var name = uri.lastPathSegment ?: "fichier sélectionné"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        if (bound) {
            unbindService(connection)
            bound = false
        }
        super.onDestroy()
    }
}
