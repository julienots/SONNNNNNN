# DualSound

Appli Android (Kotlin) qui permet de :
- 🎧 **Envoyer un son différent sur chaque écouteur** (gauche/droite) sur des écouteurs Bluetooth (appairés comme un seul appareil stéréo).
- 🌀 Appliquer un **effet 8D** sur une lecture normale, avec **4 styles de rotation** (circulaire, figure en huit, dérive aléatoire, large statique) et une **intensité réglable**.
- 🎚️ Utiliser un **égaliseur 5 bandes**, un **renfort de basses**, une **spatialisation (Virtualizer)** et une **réverbération d'ambiance**.
- ⭐ Appliquer et enregistrer des **préréglages** (Basses profondes, Voix claires, Cinéma immersif, Sommeil doux, Sport énergique, + les tiens).
- ⚙️ **Automatiser** : préréglage auto au branchement d'un casque Bluetooth, préréglage programmé à heure fixe chaque jour, minuterie de sommeil avec fondu progressif.
- ⚗️ (Expérimental) Tenter d'appliquer EQ / basses / spatialisation à **tout le son du téléphone** (session audio globale). Voir la section "Limites" ci-dessous — c'est important.
- ▶️ Tourner **en arrière-plan** via un foreground service avec notification persistante.

## ⚠️ Limites importantes (à lire avant de t'attendre à un miracle sur YouTube Music)

Aucune application Android non-rootée — DualSound comme n'importe quelle autre — ne peut **intercepter puis remplacer en temps réel** le son d'une autre appli comme YouTube Music, Spotify ou Deezer. Deux raisons, imposées par Android et par ces applis elles-mêmes, pas par un manque de code :

1. **Les applis de streaming protègent leur flux audio.** YouTube Music n'autorise pas les autres applis à capturer son audio (`AudioPlaybackCapture`), notamment pour du contenu protégé.
2. **Le Bluetooth contourne la chaîne d'effets globale.** Sur la quasi-totalité des téléphones, la sortie audio envoyée à un casque/écouteurs Bluetooth (A2DP) ne passe plus par les effets système (`Equalizer`/`BassBoost`/`Virtualizer` en session 0) — c'est vrai pour DualSound, et c'est vrai pour Wavelet, Poweramp EQ ou n'importe quelle autre appli du Play Store. Seul le **root** permet de contourner ça.

➡️ Ce que fait réellement la carte "Égaliseur système (expérimental)" : elle tente l'astuce de la session audio globale (session 0), qui peut fonctionner pour la sortie **haut-parleur ou filaire** sur certains téléphones, mais qui ne fonctionnera **pas** dès que le son sort en Bluetooth. C'est indiqué directement dans l'appli.

➡️ Ce qui fonctionne à 100%, sans limitation : tous les effets (8D, EQ, basses, spatialisation, réverbération, automatisations) sur les **fichiers audio que tu importes dans DualSound lui-même** (modes "Un son par écouteur" et "Lecture normale + 8D").

## Compiler l'APK via GitHub (sans rien installer)

1. Crée un nouveau repo GitHub (public ou privé).
2. Mets tout le contenu de ce dossier à la racine du repo (avec `.github/workflows/build.yml`).
3. Push sur la branche `main`.
4. Va dans l'onglet **Actions** du repo → le workflow *Build APK* se lance automatiquement.
5. Une fois terminé (icône verte), ouvre le run → section **Artifacts** en bas de page → télécharge `DualSound-debug-apk`.
6. Dézippe, tu obtiens `app-debug.apk`. Transfère-le sur ton téléphone et installe-le (autorise "sources inconnues" si demandé).

Tu peux aussi relancer manuellement le build depuis Actions → Build APK → "Run workflow".

## Compiler en local (optionnel)

Nécessite Android Studio (Giraffe ou plus récent) ou un JDK 17 + Android SDK.

```bash
./gradlew assembleDebug
```

L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

## Utilisation

1. Ouvre l'appli, autorise les notifications si demandé (nécessaire pour tourner en arrière-plan).
2. **Mode "un son par écouteur"** : choisis un fichier pour la gauche et un pour la droite, appuie sur Lecture. Ça boucle en continu.
3. **Mode normal + 8D** : choisis un fichier, active le switch 8D, choisis un style de rotation, ajuste vitesse et intensité, Lecture.
4. **Égaliseur / Basses & spatialisation** : les curseurs s'appliquent à tout ce qui est en cours de lecture dans l'appli.
5. **Préréglages** : choisis-en un dans la liste et appuie sur "Appliquer", ou règle tout manuellement puis "Enregistrer les réglages actuels" pour créer le tien.
6. **Égaliseur système (expérimental)** : à activer si tu veux tenter d'égaliser d'autres applis. Lis la section "Limites" plus haut avant de t'attendre à un effet sur YouTube Music en Bluetooth.
7. **Automatisations** :
   - Active "Appliquer un préréglage quand mon casque Bluetooth se connecte" et choisis le préréglage — DualSound l'appliquera (et tentera l'égaliseur système) dès que tes écouteurs se connectent. Autorise la permission Bluetooth demandée.
   - Active "Programmer un préréglage à heure fixe chaque jour", choisis l'heure et le préréglage (ex: Sommeil doux à 22h30).
   - Minuterie de sommeil : lance un fondu progressif puis arrête la lecture interne après 10/20/30/60 min.

## Notes techniques

- `minSdk 26`, `targetSdk 34`.
- Le mode "un écouteur = un son" fonctionne en jouant le fichier A avec le volume `(1,0)` et le fichier B avec `(0,1)` simultanément — ça exploite la séparation stéréo native, donc ça marche sur toute paire d'écouteurs sans fil appairée comme un seul périphérique stéréo (la quasi-totalité des TWS/casques Bluetooth grand public).
- L'égaliseur global (session 0) est une astuce non-officielle utilisée par d'autres apps d'égaliseur système ; Android ne garantit aucune API publique pour modifier le son d'autres applis sans root.
- Les automatisations utilisent `BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED` (branchement casque) et `AlarmManager.setAndAllowWhileIdle` (préréglage programmé, non exact à quelques minutes près pour éviter la permission "alarmes exactes").
- Les préréglages personnalisés sont stockés localement (SharedPreferences + JSON), rien n'est envoyé en ligne.
