# DualSound

Appli Android (Kotlin) qui permet de :
- 🎧 **Envoyer un son différent sur chaque écouteur** (gauche/droite) sur des écouteurs Bluetooth (appairés comme un seul appareil stéréo).
- 🌀 Appliquer un **effet 8D** (rotation du son) sur une lecture normale.
- 🎚️ Utiliser un **égaliseur 5 bandes**.
- ⚗️ (Expérimental) Tenter d'appliquer l'égaliseur à **tout le son du téléphone** (session audio globale). Non garanti selon les appareils, et souvent inopérant en Bluetooth — c'est une limitation d'Android, pas un bug.
- ▶️ Tourner **en arrière-plan** via un foreground service avec notification persistante.

## Compiler l'APK via GitHub (sans rien installer)

1. Crée un nouveau repo GitHub (public ou privé).
2. Mets tout le contenu de ce dossier à la racine du repo (avec `.github/workflows/build.yml`).
3. Push sur la branche `main`.
4. Va dans l'onglet **Actions** du repo → le workflow *Build APK* se lance automatiquement.
5. Une fois terminé (icône verte), ouvre le run → section **Artifacts** en bas de page → télécharge `DualSound-debug-apk`.
6. Dézippe, tu obtiens `app-debug.apk`. Transfère-le sur ton téléphone et installe-le (autorise "sources inconnues" si demandé).

Tu peux aussi relancer manuellement le build depuis Actions → Build APK → "Run workflow".

## Compiler en local (optionnel)

Nécessite Android Studio (Giraffe ou plus récent) ou un JDK 17 + Android SDK.

```bash
./gradlew assembleDebug
```

L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.

## Utilisation

1. Ouvre l'appli, autorise les notifications si demandé (nécessaire pour tourner en arrière-plan).
2. **Mode "un son par écouteur"** : choisis un fichier pour la gauche et un pour la droite, appuie sur Lecture. Ça boucle en continu.
3. **Mode normal + 8D** : choisis un fichier, active le switch 8D si tu veux la rotation, ajuste la vitesse, Lecture.
4. **Égaliseur** : les 5 curseurs s'appliquent à tout ce qui est en cours de lecture dans l'appli.
5. **Égaliseur système (expérimental)** : à activer si tu veux tenter d'égaliser Spotify/YouTube/etc. Si ça ne marche pas sur ton téléphone (message "Non supporté"), c'est une restriction Android — aucune appli sans root ne peut le garantir.

## Notes techniques

- `minSdk 26`, `targetSdk 34`.
- Le mode "un écouteur = un son" fonctionne en jouant le fichier A avec le volume `(1,0)` et le fichier B avec `(0,1)` simultanément — ça exploite la séparation stéréo native, donc ça marche sur toute paire d'écouteurs sans fil appairée comme un seul périphérique stéréo (la quasi-totalité des TWS/casques Bluetooth grand public).
- L'égaliseur global (session 0) est une astuce non-officielle utilisée par d'autres apps d'égaliseur système ; Android ne garantit aucune API publique pour modifier le son d'autres applis sans root.
